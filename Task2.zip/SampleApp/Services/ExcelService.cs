﻿using SampleApp.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OfficeOpenXml;

namespace SampleApp.Services
{
    public class ExcelService
    {
        public async Task<List<Item>> ReadFromExcelAsync(string filePath)
        {
            var items = new List<Item>();

            using (var package = new ExcelPackage(new FileInfo(filePath)))
            {
                var worksheet = package.Workbook.Worksheets[0]; // Get the first worksheet
                var rowCount = worksheet.Dimension.Rows;

                for (int row = 2; row <= rowCount; row++) // Start from row 2 to skip headers
                {
                    var item = new Item
                    {
                        Id = int.Parse(worksheet.Cells[row, 1].Text), // Assuming Id is in column 1
                        Name = worksheet.Cells[row, 2].Text, // Name in column 2
                        Description = worksheet.Cells[row, 3].Text // Description in column 3
                    };
                    items.Add(item);
                }
            }

            return items;
        }

        public async Task WriteToExcelAsync(string filePath, List<Item> items)
        {
            using (var package = new ExcelPackage())
            {
                var worksheet = package.Workbook.Worksheets.Add("Items");

                // Add headers
                worksheet.Cells[1, 1].Value = "Id";
                worksheet.Cells[1, 2].Value = "Name";
                worksheet.Cells[1, 3].Value = "Description";

                for (int i = 0; i < items.Count; i++)
                {
                    worksheet.Cells[i + 2, 1].Value = items[i].Id;
                    worksheet.Cells[i + 2, 2].Value = items[i].Name;
                    worksheet.Cells[i + 2, 3].Value = items[i].Description;
                }

                await package.SaveAsAsync(new FileInfo(filePath));
            }
        }
    }
}
